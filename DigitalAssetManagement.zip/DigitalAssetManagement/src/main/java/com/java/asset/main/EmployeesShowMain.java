package com.java.asset.main;

import java.sql.SQLException;
import java.util.List;

import com.java.asset.dao.EmployeesDao;
import com.java.asset.dao.EmployeesDaoImpl;
import com.java.asset.model.Employees;

public class EmployeesShowMain {

	      public static void main(String[] args) {
			EmployeesDao dao = new EmployeesDaoImpl();
			try {
				List<Employees> employeeList = dao.showEmployeesDao();
				for (Employees employees : employeeList) {
					System.out.println(employees);
				}
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
}

package com.java.asset.main;

import java.sql.SQLException;
import java.util.Scanner;
import java.util.List;

import com.java.asset.dao.EmployeesDao;
import com.java.asset.dao.EmployeesDaoImpl;
import com.java.asset.model.Employees;

public class EmployeesDeleteMain {

	public static void main(String[] args) {
		int employee_id;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Employee Id  ");
		employee_id = sc.nextInt();
		EmployeesDao dao = new EmployeesDaoImpl();
		try {
			System.out.println(dao.deleteEmployeesDao(employee_id));
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
}
	}


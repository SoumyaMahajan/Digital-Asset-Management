package com.java.asset.exceptions;

public class AssetNotMaintainException extends Exception{

	  public AssetNotMaintainException(String message) {
	        super(message);
	    }
}

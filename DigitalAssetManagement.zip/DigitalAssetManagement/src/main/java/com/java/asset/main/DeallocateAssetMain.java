package com.java.asset.main;

import java.sql.SQLException;
import java.util.Scanner;
import com.java.asset.dao.AssetManagementService;
import com.java.asset.dao.AssetManagementServiceImpl;
import com.java.asset.exceptions.AssetNotFoundException;

public class DeallocateAssetMain {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        AssetManagementService assetService = new AssetManagementServiceImpl();

        System.out.println("Enter asset ID to deallocate:");
        int asset_id = scanner.nextInt();

        try {
            if (assetService.checkAssetExists(asset_id)) {
                System.out.println("Enter employee ID:");
                int employee_id = scanner.nextInt();
                System.out.println("Enter return date:");
                String return_date = scanner.next();
                boolean deallocated = assetService.deallocateAsset(asset_id, employee_id, return_date);
                if (deallocated) {
                    System.out.println("Asset deallocated successfully");
                } 
            } else {
                throw new AssetNotFoundException("Deallocate function cannot be performed... ");
            }
        } catch (ClassNotFoundException e) {
            System.out.println("Error: Class not found.");
        } catch (SQLException e) {
            System.out.println("Error executing SQL query: " + e.getMessage());
        } catch (AssetNotFoundException e) {
            System.out.println("Asset not found "+e.getMessage());
        } 
    }
}

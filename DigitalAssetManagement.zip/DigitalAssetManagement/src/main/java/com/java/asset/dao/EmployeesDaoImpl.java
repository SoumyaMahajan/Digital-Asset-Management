package com.java.asset.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.java.asset.model.Employees;
import com.java.asset.util.DBConnUtil;
import com.java.asset.util.DBPropertyUtil;


public class EmployeesDaoImpl implements EmployeesDao{

	Connection connection;
	PreparedStatement pst;
	@Override
	public List<Employees> showEmployeesDao() throws ClassNotFoundException, SQLException {
		String connStr =DBPropertyUtil.connectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		String cmd = "select * from Employees";
		pst = connection.prepareStatement(cmd);
		ResultSet rs = pst.executeQuery();
		List<Employees> employeeList = new ArrayList<Employees>();
		Employees employee = null;
		while(rs.next()) {
			employee = new Employees();
			employee.setEmployee_id(rs.getInt("employee_id"));
			employee.setName(rs.getString("name"));
			employee.setDepartment(rs.getString("department"));
			employee.setEmail(rs.getString("email"));
			employee.setPassword(rs.getString("password"));
			employeeList.add(employee);
		}
		return employeeList;
		
	}

	@Override
	public Employees searchByEmployee_id(int empId) throws ClassNotFoundException, SQLException {
		String connStr =DBPropertyUtil.connectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		String cmd = "select * from Employees where Employee_id = ?";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, empId);
		ResultSet rs = pst.executeQuery();
		Employees employee = null;
		if(rs.next()) {
			employee = new Employees();
			employee.setEmployee_id(rs.getInt("employee_id"));
			employee.setName(rs.getString("name"));
			employee.setDepartment(rs.getString("department"));
			employee.setEmail(rs.getString("email"));
			employee.setPassword(rs.getString("password"));
		}
		return employee;
	}

	@Override
	public String addEmployeesDao(Employees employee) throws ClassNotFoundException, SQLException {
		String connStr =DBPropertyUtil.connectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		String password = EncryptPassword.getCode(employee.getPassword());
		employee.setPassword(password);
		String cmd = "Insert into Employees(Employee_id, Name, Department, Email, Password) "
				+ " values(?,?,?,?,?)";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, employee.getEmployee_id());
		pst.setString(2, employee.getName());
		pst.setString(3, employee.getDepartment());
		pst.setString(4, employee.getEmail());
		pst.setString(5, employee.getPassword());
		pst.executeUpdate();
		SendMail.mailSend("soumya.mmahajan@gmail.com", "My First Java Mail", "Hexaware Training");
		return "Employees Record Inserted...";
	}

	@Override
	public String updateEmployeesDao(Employees employee) throws ClassNotFoundException, SQLException {
		Employees employeesFound = searchByEmployee_id(employee.getEmployee_id());
		if (employeesFound!=null) {
			String connStr = DBPropertyUtil.connectionString("db");
			connection = DBConnUtil.getConnection(connStr);
			String cmd = "Update Employees set Name = ?, Department = ?, Email = ?, Password = ? where employee_id = ?";
			pst = connection.prepareStatement(cmd);
			pst.setString(1, employee.getName());
			pst.setString(2, employee.getDepartment());
			pst.setString(3, employee.getEmail());
			pst.setString(4, employee.getPassword());
			pst.setInt(5, employee.getEmployee_id());
			pst.executeUpdate();
			return "*** Employee Record Updated ***";
		}
		return "*** Employee Record Not Updated ***";
	}

	



	@Override
	public String deleteEmployeesDao(int employee_id) throws ClassNotFoundException, SQLException {
		Employees employeesFound = searchByEmployee_id(employee_id);
		if (employeesFound !=null) {
			String connStr = DBPropertyUtil.connectionString("db");
			connection = DBConnUtil.getConnection(connStr);
			String cmd = "Delete From Employees Where employee_id = ?";
			pst = connection.prepareStatement(cmd);
			pst.setInt(1, employee_id);
			pst.executeUpdate();
			return "*** Employee Record Deleted ***";
		}
		return "*** Employee Record Not Found ***";
	}

	
	

}

package com.java.asset.main;

import java.sql.SQLException;
import java.util.Scanner;
import java.util.List;

import com.java.asset.dao.EmployeesDao;
import com.java.asset.dao.EmployeesDaoImpl;
import com.java.asset.model.Employees;

public class EmployeesSearchMain {

	       public static void main(String[] args) {
			int empId;
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter Employee Id");
			empId = sc.nextInt();
			EmployeesDao dao = new EmployeesDaoImpl();
			try {
				Employees employee = dao.searchByEmployee_id(empId);
				if (employee!= null) {
					System.out.println(employee);
				}else {
					System.out.println("*** Employee Record Not Found ***");
				}
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
		}
}

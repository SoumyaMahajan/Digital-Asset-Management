package com.java.asset.main;

import java.sql.SQLException;
import java.util.Scanner;
import com.java.asset.dao.AssetManagementService;
import com.java.asset.dao.AssetManagementServiceImpl;
import com.java.asset.exceptions.AssetNotFoundException;
import com.java.asset.exceptions.AssetNotMaintainException;

public class AllocateAssetMain {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        AssetManagementService assetService = new AssetManagementServiceImpl();

        System.out.println("Enter asset ID to allocate:");
        int asset_id = scanner.nextInt();
        scanner.nextLine();

        try {
            if (assetService.checkAssetExists(asset_id)) {
            	if (!assetService.checkAssetMaintenance(asset_id)) {
                    throw new AssetNotMaintainException("Asset with ID " + asset_id + " requires maintenance but has not been maintained for two years.");
                }
            	System.out.println("Enter employee ID to allocate:");
                int employee_id = scanner.nextInt();
                System.out.println("Enter allocation date :");
                String allocation_date = scanner.next();
                boolean allocated = assetService.allocateAsset(asset_id, employee_id, allocation_date);
                if (allocated) {
                    System.out.println("Asset allocated successfully");
                } 
            }
            else {
            	throw new AssetNotFoundException("Allocate assets function cannot be performed...");
            }
        } catch (ClassNotFoundException e) {
            System.out.println("Error: Class not found.");
        }
        catch (SQLException e) {
            System.out.println("Error executing SQL query");
        }
        catch (AssetNotFoundException e) {
        	System.out.println("Asset is not Found. "+e.getMessage());
        }
        catch (AssetNotMaintainException e) {
        	System.out.println("Asset is not Maintained. "+e.getMessage());
        }
        
    }
}

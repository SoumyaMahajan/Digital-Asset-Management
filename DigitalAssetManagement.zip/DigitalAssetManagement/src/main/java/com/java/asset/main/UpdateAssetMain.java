/*package com.java.asset.main;

import java.sql.Date;
import java.sql.SQLException;
import java.util.Scanner;
import com.java.asset.dao.AssetsDao;
import com.java.asset.dao.AssetsDaoImpl;
import com.java.asset.model.Assets;
import com.java.asset.exceptions.AssetNotFoundException;

public class UpdateAssetMain {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        AssetsDao assetService = new AssetsDaoImpl();

        System.out.println("Enter asset details to update:");
        System.out.print("Asset ID: ");
        int asset_id = scanner.nextInt();
        scanner.nextLine();
        
        try {
        	if (assetService.checkAssetExists(asset_id)) {
        		System.out.print("Name: ");
                String name = scanner.nextLine();
                System.out.print("Type: ");
                String type = scanner.nextLine();
                System.out.print("Serial Number: ");
                int serial_number = scanner.nextInt();
                scanner.nextLine();
                System.out.print("Purchase Date:");
                String purchase_date = scanner.nextLine();
                System.out.print("Location: ");
                String location = scanner.nextLine();
                System.out.print("Status: ");
                String status = scanner.nextLine();
                System.out.print("Owner ID: ");
                int owner_id = scanner.nextInt();
                Assets asset = new Assets(asset_id, name, type, serial_number, Date.valueOf(purchase_date), location, status, owner_id);
                boolean updated = assetService.updateAsset(asset);
            if (updated) {
                System.out.println("Asset updated successfully.");
            }
          }
            else {
            	throw new AssetNotFoundException("Update function cannot be performed...");
            }
          
        } 
        catch (ClassNotFoundException e) {
            System.out.println("Error: Class not found.");
        }
        catch (SQLException e) {
            System.out.println("Error executing SQL query");
        }
        catch (AssetNotFoundException e) {
        	System.out.println("Asset is not Found. "+e.getMessage());
        }
       
    }
}*/


package com.java.asset.main;

import java.sql.Date;
import java.sql.SQLException;
import java.util.Scanner;
import com.java.asset.dao.AssetManagementService;
import com.java.asset.dao.AssetManagementServiceImpl;
import com.java.asset.model.Assets;
import com.java.asset.exceptions.AssetNotFoundException;

public class UpdateAssetMain {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        AssetManagementService assetService = new AssetManagementServiceImpl();

        System.out.println("Enter asset details to update:");
        System.out.print("Asset ID: ");
        int asset_id = scanner.nextInt();
        scanner.nextLine();
        
        try {
        	if (assetService.checkAssetExists(asset_id)) {
        		System.out.print("Name: ");
                String name = scanner.nextLine();
                System.out.print("Type: ");
                String type = scanner.nextLine();
                System.out.print("Serial Number: ");
                int serial_number = scanner.nextInt();
                scanner.nextLine();
                System.out.print("Purchase Date:");
                String purchase_date = scanner.nextLine();
                System.out.print("Location: ");
                String location = scanner.nextLine();
                System.out.print("Status: ");
                String status = scanner.nextLine();
                System.out.print("Owner ID: ");
                int owner_id = scanner.nextInt();
                Assets asset = new Assets(asset_id, name, type, serial_number, Date.valueOf(purchase_date), location, status, owner_id);
                boolean updated = assetService.updateAsset(asset);
            if (updated) {
                System.out.println("Asset updated successfully.");
            }
          }
            else {
            	throw new AssetNotFoundException("Update function cannot be performed...");
            }
          
        } 
        catch (ClassNotFoundException e) {
            System.out.println("Error: Class not found.");
        }
        catch (SQLException e) {
            System.out.println("Error executing SQL query");
        }
        catch (AssetNotFoundException e) {
        	System.out.println("Asset is not Found. "+e.getMessage());
        }
       
    }
}


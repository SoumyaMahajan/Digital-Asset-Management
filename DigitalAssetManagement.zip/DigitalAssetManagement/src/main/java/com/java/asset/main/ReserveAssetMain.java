package com.java.asset.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.asset.dao.AssetManagementService;
import com.java.asset.dao.AssetManagementServiceImpl;
import com.java.asset.exceptions.AssetNotFoundException;
import com.java.asset.exceptions.AssetNotMaintainException;

public class ReserveAssetMain {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        AssetManagementService assetService = new AssetManagementServiceImpl();

        System.out.println("Enter asset ID to reserve:");
        int asset_id = scanner.nextInt();

        try {
            if (assetService.checkAssetExists(asset_id)) {
            	if (!assetService.checkAssetMaintenance(asset_id)) {
                    throw new AssetNotMaintainException("Asset with ID " + asset_id + " requires maintenance but has not been maintained for two years.");
                }
                System.out.println("Enter employee ID to reserve:");
                int employee_id = scanner.nextInt();
                scanner.nextLine(); 
                
                System.out.println("Enter reservation date:");
                String reservation_date = scanner.nextLine().trim();

                System.out.println("Enter start date :");
                String start_date = scanner.nextLine().trim();

                System.out.println("Enter end date :");
                String end_date = scanner.nextLine().trim();

                boolean reserved = assetService.reserveAsset(asset_id, employee_id, reservation_date, start_date, end_date);
                if (reserved) {
                    System.out.println("Asset reserved successfully");
                } else {
                    System.out.println("Failed to reserve asset");
                }
            } else {
            	throw new AssetNotFoundException("Reserve function cannot be performed... ");
            }
        } catch (ClassNotFoundException e) {
            System.out.println("Error: Class not found.");
        } catch (SQLException e) {
            System.out.println("Error executing SQL query: " + e.getMessage());
        } 
        catch (AssetNotFoundException e) {
            System.out.println("Asset not found. "+e.getMessage());
        }
        catch (AssetNotMaintainException e) {
        	System.out.println("Asset is not Maintained. "+e.getMessage());
        }
    }
}


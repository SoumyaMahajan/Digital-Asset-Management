package com.java.asset.model;

import java.util.Date;
import java.util.Objects;

public class MaintenanceRecords {

	private int maintenance_id;
	private int asset_id;
	private Date maintenance_date;
	private String description;
	private double cost;
	public int getMaintenance_id() {
		return maintenance_id;
	}
	public void setMaintenance_id(int maintenance_id) {
		this.maintenance_id = maintenance_id;
	}
	public int getAsset_id() {
		return asset_id;
	}
	public void setAsset_id(int asset_id) {
		this.asset_id = asset_id;
	}
	public Date getMaintenance_date() {
		return maintenance_date;
	}
	public void setMaintenance_date(Date maintenance_date) {
		this.maintenance_date = maintenance_date;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}
	
	public MaintenanceRecords() {
		
	}
	
	public MaintenanceRecords(int maintenance_id, int asset_id, Date maintenance_date, String description, double cost) {
		this.maintenance_id = maintenance_id;
		this.asset_id = asset_id;
		this.maintenance_date = maintenance_date;
		this.description = description;
		this.cost = cost;
	}
	
	@Override
	public String toString() {
		return "MaintenanceRecords [maintenance_id=" + maintenance_id + ", asset_id=" + asset_id + ", maintenance_date="
				+ maintenance_date + ", description=" + description + ", cost=" + cost + "]";
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(asset_id, cost, description, maintenance_date, maintenance_id);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MaintenanceRecords other = (MaintenanceRecords) obj;
		return asset_id == other.asset_id && Double.doubleToLongBits(cost) == Double.doubleToLongBits(other.cost)
				&& Objects.equals(description, other.description)
				&& Objects.equals(maintenance_date, other.maintenance_date) && maintenance_id == other.maintenance_id;
	}
}
package com.java.asset.main;

import java.util.Scanner;

import com.java.asset.dao.AssetManagementService;
import com.java.asset.dao.AssetManagementServiceImpl;

public class WithdrawReservationMain {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        AssetManagementService assetService = new AssetManagementServiceImpl();

        System.out.println("Enter reservation ID to withdraw:");
        int reservation_id = scanner.nextInt();

        try {
            boolean withdrawn = assetService.withdrawReservation(reservation_id);
            if (withdrawn) {
                System.out.println("Reservation withdrawn successfully");
            } else {
                System.out.println("Failed to withdraw reservation,Invalid Reservation_id");
            }
        } catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}

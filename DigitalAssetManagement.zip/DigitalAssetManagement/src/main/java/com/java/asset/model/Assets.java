package com.java.asset.model;

import java.util.Date;
import java.util.Objects;

public class Assets {
           
	private int asset_id;
	private String name;
	private String type;
	private int serial_number;
	private Date purchase_date;
	private String location;
	private String status;
	private int owner_id;
	
	public int getAsset_id() {
		return asset_id;
	}
	public void setAsset_id(int asset_id) {
		this.asset_id = asset_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getSerial_number() {
		return serial_number;
	}
	public void setSerial_number(int serial_number) {
		this.serial_number = serial_number;
	}
	public Date getPurchase_date() {
		return purchase_date;
	}
	public void setPurchase_date(Date purchase_date) {
		this.purchase_date = purchase_date;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getOwner_id() {
		return owner_id;
	}
	public void setOwner_id(int owner_id) {
		this.owner_id = owner_id;
	}
	
	public Assets() {
		
	}
	
	public Assets(int asset_id, String name, String type, int serial_number, Date purchase_date, String location,
			String status, int owner_id) {
		this.asset_id = asset_id;
		this.name = name;
		this.type = type;
		this.serial_number = serial_number;
		this.purchase_date = purchase_date;
		this.location = location;
		this.status = status;
		this.owner_id = owner_id;
	}
	
	@Override
	public String toString() {
		return "Assets [asset_id=" + asset_id + ", name=" + name + ", type=" + type + ", serial_number=" + serial_number
				+ ", purchase_date=" + purchase_date + ", location=" + location + ", status=" + status + ", owner_id="
				+ owner_id + "]";
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(asset_id, location, name, owner_id, purchase_date, serial_number, status, type);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Assets other = (Assets) obj;
		return asset_id == other.asset_id && Objects.equals(location, other.location) && Objects.equals(name, other.name)
				&& owner_id == other.owner_id && Objects.equals(purchase_date, other.purchase_date)
				&& serial_number == other.serial_number && Objects.equals(status, other.status)
				&& Objects.equals(type, other.type);
	}
	
	
	
	
	
	
}

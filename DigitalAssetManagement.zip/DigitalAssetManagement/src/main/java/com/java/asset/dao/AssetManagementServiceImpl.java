package com.java.asset.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;

import com.java.asset.exceptions.AssetNotFoundException;
import com.java.asset.model.Assets;
import com.java.asset.util.DBConnUtil;
import com.java.asset.util.DBPropertyUtil;

public class AssetManagementServiceImpl implements AssetManagementService {
	
	Connection connection;
	PreparedStatement pst;
	
	@Override
	public boolean addAsset(Assets asset) throws ClassNotFoundException {
		try {
	        String connStr = com.java.asset.util.DBPropertyUtil.connectionString("db");
	        connection = com.java.asset.util.DBConnUtil.getConnection(connStr);
	        String cmd = "insert into assets (asset_id, name, type, serial_number, purchase_date, location, status, owner_id) " +
	                     "values (?, ?, ?, ?, ?, ?, ?, ?)";
	        pst = connection.prepareStatement(cmd);
	        pst.setInt(1, asset.getAsset_id());  
	        pst.setString(2, asset.getName());
	        pst.setString(3, asset.getType());
	        pst.setInt(4, asset.getSerial_number());
	        pst.setDate(5,(Date)asset.getPurchase_date());
	        pst.setString(6, asset.getLocation());
	        pst.setString(7, asset.getStatus());
	        pst.setInt(8, asset.getOwner_id());

	        int rowsAffected = pst.executeUpdate();
	        return rowsAffected > 0;
	    } catch (SQLException e) {
	        e.printStackTrace();
	        return false; 
	    }
	}
	
	
	@Override
	public boolean updateAsset(Assets asset) throws ClassNotFoundException, AssetNotFoundException {
		 try {
		    	if (checkAssetExists(asset.getAsset_id())) {
		        String connStr = DBPropertyUtil.connectionString("db");
		        connection = DBConnUtil.getConnection(connStr);
		        String cmd = "update assets "+
		        "set name = ?, type = ?, serial_number = ?, purchase_date = ?, location = ?, status = ?, owner_id = ? " +
		        "where asset_id = ?";
		        pst = connection.prepareStatement(cmd);
		        pst.setString(1, asset.getName());
		        pst.setString(2, asset.getType());
		        pst.setInt(3, asset.getSerial_number());
		        pst.setDate(4,(java.sql.Date)asset.getPurchase_date());
		        pst.setString(5, asset.getLocation());
		        pst.setString(6, asset.getStatus());
		        pst.setInt(7, asset.getOwner_id());
		        pst.setInt(8, asset.getAsset_id());
		        pst.executeUpdate();
		        return true;
		    	}
		        else{
		    		throw new AssetNotFoundException("Asset is not found");
		        }
		     }
		  catch (SQLException e) {
		        e.printStackTrace();
		        return false;
		    }   
	}
	
	
	@Override
	public boolean deleteAsset(int asset_id) throws ClassNotFoundException, AssetNotFoundException {
		try {
	    	if (!checkAssetExists(asset_id)) {
	    		throw new AssetNotFoundException("Asset is not found");
	        }
	        String connStr = DBPropertyUtil.connectionString("db");
	        connection = DBConnUtil.getConnection(connStr);
	        String cmd = "delete from assets where asset_id = ?";
	        pst = connection.prepareStatement(cmd);
	        pst.setInt(1, asset_id);
	        pst.executeUpdate();
	        return true;
	        
	    } catch (SQLException e) {
	        e.printStackTrace();
	        return false;
	    }catch (AssetNotFoundException e) {
	        e.printStackTrace();
	        return false;
	    }
	}
	@Override
	public boolean allocateAsset(int asset_id, int employee_id, String allocation_date)
			throws ClassNotFoundException, AssetNotFoundException {
		 try {
		    	if (!checkAssetExists(asset_id)) {
		    		throw new AssetNotFoundException("Asset is not found");
		        }
		        String connStr = DBPropertyUtil.connectionString("db");
		        connection = DBConnUtil.getConnection(connStr);
		        String cmd = "insert into asset_allocations (asset_id, employee_id, allocation_date) values (?, ?, ?)";
		        pst = connection.prepareStatement(cmd);
		        pst.setInt(1, asset_id);
		        pst.setInt(2, employee_id);
		        pst.setDate(3, (java.sql.Date)valueOf(allocation_date));
		        pst.executeUpdate();
		        return true;
		       
		    } catch (SQLException e) {
		        e.printStackTrace();
		        return false;
		    }
	}
	
	
	@Override
	public boolean deallocateAsset(int asset_id, int employee_id, String return_date)
			throws ClassNotFoundException, AssetNotFoundException {
		try {
	    	if (!checkAssetExists(asset_id)) {
	    		throw new AssetNotFoundException("Asset is not found");
	        }
	        String connStr = DBPropertyUtil.connectionString("db");
	        connection = DBConnUtil.getConnection(connStr);
	        String cmd = "update asset_allocations set return_date = ? where asset_id = ? and employee_id = ?";
	        pst = connection.prepareStatement(cmd);
	        pst.setDate(1, (java.sql.Date)valueOf(return_date));
	        pst.setInt(2, asset_id);
	        pst.setInt(3, employee_id);
	        pst.executeUpdate();
	        return true;
	    } catch (SQLException e) {
	        e.printStackTrace();
	        return false;
	    }
	}
	
	
	@Override
	public boolean performMaintenance(int asset_id, String maintenance_date, String description, double cost)
			throws ClassNotFoundException, SQLException, AssetNotFoundException {
		 try {
		        String connStr = DBPropertyUtil.connectionString("db");
		        connection = DBConnUtil.getConnection(connStr);

		        String cmd = "insert into maintenance_records (asset_id, maintenance_date, description, cost) values (?, ?, ?, ?)";
		        pst = connection.prepareStatement(cmd);
		        pst.setInt(1, asset_id);
		        pst.setDate(2, (java.sql.Date)valueOf(maintenance_date));
		        pst.setString(3, description);
		        pst.setDouble(4, cost);

		        int rowsAffected = pst.executeUpdate();
		        return rowsAffected > 0;
		    } catch (SQLException e) {
		        e.printStackTrace();
		        return false;
		    }
	}
	
	
	@Override
	public boolean reserveAsset(int asset_id, int employee_id, String reservation_date, String start_date,
			String end_date) throws ClassNotFoundException, AssetNotFoundException {
		try {
	    	if (!checkAssetExists(asset_id)) {
	    		throw new AssetNotFoundException("Asset is not found");
	        }
	        String connStr = DBPropertyUtil.connectionString("db");
	        connection = DBConnUtil.getConnection(connStr);
	        String cmd = "insert into reservations (asset_id, employee_id, reservation_date, start_date, end_date, status) values (?, ?, ?, ?, ?, ?)";
	        pst = connection.prepareStatement(cmd);
	        pst.setInt(1, asset_id);
	        pst.setInt(2, employee_id);
	        pst.setDate(3, (java.sql.Date)valueOf(reservation_date));
	        pst.setDate(4, (java.sql.Date)valueOf(start_date));
	        pst.setDate(5, (java.sql.Date)valueOf(end_date));
	        pst.setString(6, "Confirmed");
	        pst.executeUpdate();
	        return true;
	    } catch (SQLException e) {
	        e.printStackTrace();
	        return false;
	    }
	}
	@Override
	public boolean withdrawReservation(int reservation_id) throws ClassNotFoundException {
		 try {
		        String connStr = DBPropertyUtil.connectionString("db");
		        connection = DBConnUtil.getConnection(connStr);
		        String cmd = "delete from reservations where reservation_id = ?";
		        pst = connection.prepareStatement(cmd);
		        pst.setInt(1, reservation_id);
		        int rowsAffected = pst.executeUpdate();
		        return rowsAffected > 0;
		    } catch (SQLException e) {
		        e.printStackTrace();
		        return false;
		    }
	}
	
	
	@Override
	public boolean checkAssetExists(int asset_id) throws ClassNotFoundException, SQLException, ClassNotFoundException {
		try {
	    	 String connStr = DBPropertyUtil.connectionString("db");
		    connection = DBConnUtil.getConnection(connStr);
	        String cmd = "select count(*) from assets where asset_id = ?";
	        pst = connection.prepareStatement(cmd);
	        pst.setInt(1, asset_id);
	        ResultSet rs = pst.executeQuery();
	        if (rs.next() && rs.getInt(1) > 0) {
	            return true;
	        } else {
	            return false;
	        }
		}
		finally {
	        if (pst != null) {
	            pst.close();
	        }
	}
	}
	
	
	@Override
	public boolean checkAssetMaintenance(int asset_id)
			throws ClassNotFoundException, SQLException, ClassNotFoundException {
		try {
	        // Establish database connection
	        String connStr = DBPropertyUtil.connectionString("db");
	        connection = DBConnUtil.getConnection(connStr);
	        
	        // SQL query to check maintenance records for the asset within the last two years
	        String cmd = "select count(*) from maintenance_records where asset_id = ? and maintenance_date >= date_Sub(curdate(), interval 2 year)";
	        pst = connection.prepareStatement(cmd);
	        pst.setInt(1, asset_id);
	        ResultSet rs = pst.executeQuery();

	        // If there are maintenance records within the last two years, set isMaintained to true
	        if (rs.next()) {
	            int count = rs.getInt(1);
	            if (count > 0) {
	                return true;
	            }
	        }
	        else{
	        	return false;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
		return false; 
	}

	}

	
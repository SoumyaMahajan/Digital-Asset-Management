package com.java.asset.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.asset.dao.EmployeesDao;
import com.java.asset.dao.EmployeesDaoImpl;
import com.java.asset.model.Employees;

public class EmployeesInsertMain {

	         public static void main(String[] args) {
				Employees employee = new Employees();
				Scanner sc = new Scanner(System.in);
				System.out.println("Enter Employee Id ");
				employee.setEmployee_id(sc.nextInt());
				System.out.println("Enter Employee Name ");
				employee.setName(sc.next());
				System.out.println("Enter Employee Department ");
				employee.setDepartment(sc.next());
				System.out.println("Enter Employee Email ");
				employee.setEmail(sc.next());
				System.out.println("Enter Employee Password ");
				employee.setPassword(sc.next());
				
				EmployeesDao dao = new EmployeesDaoImpl();
				try {
					System.out.println(dao.addEmployeesDao(employee));
					}
				 catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
}

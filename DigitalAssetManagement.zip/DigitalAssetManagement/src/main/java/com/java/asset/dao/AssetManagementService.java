package com.java.asset.dao;

import java.sql.SQLException;
import java.util.Date;

import com.java.asset.model.Assets;
import com.java.asset.exceptions.AssetNotFoundException;
import com.java.asset.exceptions.AssetNotMaintainException;

public interface AssetManagementService {

	 boolean addAsset(Assets asset) throws ClassNotFoundException;
	 boolean updateAsset(Assets asset) throws ClassNotFoundException,AssetNotFoundException;
	 boolean deleteAsset(int asset_id) throws ClassNotFoundException,AssetNotFoundException;
	 boolean allocateAsset(int asset_id, int employee_id, String allocation_date) throws ClassNotFoundException,AssetNotFoundException;
	 boolean deallocateAsset(int asset_id, int employee_id, String return_date) throws ClassNotFoundException,AssetNotFoundException;
	 boolean performMaintenance(int asset_id, String maintenance_date, String description, double cost) throws ClassNotFoundException, SQLException, AssetNotFoundException;
	 boolean reserveAsset(int asset_id, int employee_id, String reservation_date, String start_date, String end_date) throws ClassNotFoundException,AssetNotFoundException;
	 boolean withdrawReservation(int reservation_id) throws ClassNotFoundException;
	 boolean checkAssetExists(int asset_id) throws ClassNotFoundException, SQLException,ClassNotFoundException;
	 boolean checkAssetMaintenance(int asset_id) throws ClassNotFoundException, SQLException,ClassNotFoundException;

}
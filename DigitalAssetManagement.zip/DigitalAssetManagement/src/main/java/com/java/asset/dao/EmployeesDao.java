package com.java.asset.dao;

import java.sql.SQLException;
import java.util.List;

import com.java.asset.model.Employees;
import com.java.asset.util.DBConnUtil;
import com.java.asset.util.DBPropertyUtil;

public interface EmployeesDao {

	       List<Employees> showEmployeesDao() throws ClassNotFoundException, SQLException;
	       Employees searchByEmployee_id(int employee_id) throws ClassNotFoundException, SQLException;
	       String addEmployeesDao(Employees employee) throws ClassNotFoundException, SQLException;
		   String updateEmployeesDao(Employees employee) throws ClassNotFoundException, SQLException;
		   String deleteEmployeesDao(int employee_id) throws ClassNotFoundException, SQLException;
}

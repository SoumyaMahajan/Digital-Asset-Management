package com.java.asset.exceptions;

public class AssetNotFoundException extends Exception {

	 public AssetNotFoundException(String message) {
	        super(message);
	    }
}

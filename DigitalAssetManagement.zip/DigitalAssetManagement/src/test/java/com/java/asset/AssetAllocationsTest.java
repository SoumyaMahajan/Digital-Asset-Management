package com.java.asset;

import static org.junit.Assert.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.junit.Test;

import com.java.asset.model.AssetAllocations;

public class AssetAllocationsTest {

    @Test
    public void testToString() throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        AssetAllocations assetAllocation = new AssetAllocations(1, 1, 1, (sdf.parse("2024-01-10")), (sdf.parse("2024-01-15")));
        String expected = "AssetAllocations [allocation_id=1, asset_id=1, employee_id=1, allocation_date="+sdf.parse("2024-01-10")+ ", return_date="+sdf.parse("2024-01-15")+"]";
        assertEquals(expected, assetAllocation.toString());
    }

    @Test
    public void testEquals() throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        AssetAllocations assetAllocation1 = new AssetAllocations(1, 1, 1, (sdf.parse("2024-01-10")), (sdf.parse("2024-01-15")));
        AssetAllocations assetAllocation2 = new AssetAllocations(1, 1, 1, (sdf.parse("2024-01-10")), (sdf.parse("2024-01-15")));
        AssetAllocations assetAllocation3 = new AssetAllocations(2, 2, 2, (sdf.parse("2024-01-15")), (sdf.parse("2024-01-20")));
        assertTrue(assetAllocation1.equals(assetAllocation2));
        assertFalse(assetAllocation1.equals(assetAllocation3));
    }

    @Test
    public void testHashCode() throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        AssetAllocations assetAllocation1 = new AssetAllocations(1, 1, 1, (sdf.parse("2024-01-10")), (sdf.parse("2024-01-15")));
        AssetAllocations assetAllocation2 = new AssetAllocations(1, 1, 1, (sdf.parse("2024-01-10")), (sdf.parse("2024-01-15")));
        assertEquals(assetAllocation1.hashCode(), assetAllocation2.hashCode());
    }

    @Test
    public void testGettersAndSetters() throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        
        AssetAllocations assetAllocation = new AssetAllocations();
        assetAllocation.setAllocation_id(1);
        assetAllocation.setAsset_id(1);
        assetAllocation.setEmployee_id(1);
        assetAllocation.setAllocation_date((sdf.parse("2024-01-10")));
        assetAllocation.setReturn_date((sdf.parse("2024-01-15")));
        

        assertEquals(1, assetAllocation.getAllocation_id());
        assertEquals(1, assetAllocation.getAsset_id());
        assertEquals(1, assetAllocation.getEmployee_id());
        assertEquals((sdf.parse("2024-01-10")), assetAllocation.getAllocation_date());
        assertEquals((sdf.parse("2024-01-15")), assetAllocation.getReturn_date());
        
    }

    @Test
    public void testConstructors() throws ParseException {
        AssetAllocations assetAllocation = new AssetAllocations();
        assertNotNull(assetAllocation);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
   
        AssetAllocations constructedAssetAllocation = new AssetAllocations(1, 1, 1,(sdf.parse("2024-01-10")),(sdf.parse("2024-01-15")));

        assertEquals(1, constructedAssetAllocation.getAllocation_id());
        assertEquals(1, constructedAssetAllocation.getAsset_id());
        assertEquals(1, constructedAssetAllocation.getEmployee_id());
        assertEquals((sdf.parse("2024-01-10")), constructedAssetAllocation.getAllocation_date());
        assertEquals((sdf.parse("2024-01-15")), constructedAssetAllocation.getReturn_date());
       
    }
}

package com.java.asset;

import static org.junit.Assert.*;

import org.junit.Test;

import com.java.asset.model.Employees;

public class EmployeesTest {

    @Test
    public void testToString() {
        Employees emp1 = new Employees(1, "John Doe", "HR", "john@example.com", "john");
        String expected = "Employees [employee_id=1, name=John Doe, department=HR, email=john@example.com, password=john]";
        assertEquals(expected, emp1.toString());
    }

    @Test
    public void testEquals() {
        Employees emp1 = new Employees(1, "John Doe", "HR", "john@example.com", "john");
        Employees emp2 = new Employees(1, "John Doe", "HR", "john@example.com", "john");
        Employees emp3 = new Employees(2, "Jane Smith", "Marketing", "jane@example.com", "jane");
        assertTrue(emp1.equals(emp2));
        assertFalse(emp1.equals(emp3));
    }

    @Test
    public void testHashCode() {
        Employees emp1 = new Employees(1, "John Doe", "HR", "john@example.com", "john");
        Employees emp2 = new Employees(1, "John Doe", "HR", "john@example.com", "john");
        assertEquals(emp1.hashCode(), emp2.hashCode());
    }

    @Test
    public void testGettersAndSetters() {
        Employees employee = new Employees();
        employee.setEmployee_id(1);
        employee.setName("John Doe");
        employee.setDepartment("HR");
        employee.setEmail("john@example.com");
        employee.setPassword("john");
        assertEquals(1, employee.getEmployee_id());
        assertEquals("John Doe", employee.getName());
        assertEquals("HR", employee.getDepartment());
        assertEquals("john@example.com", employee.getEmail());
        assertEquals("john", employee.getPassword());
    }

    @Test
    public void testConstructors() {
        Employees employee = new Employees();
        assertNotNull(employee);
        Employees emp = new Employees(1, "John Doe", "HR", "john@example.com", "john");
        assertEquals(1, emp.getEmployee_id());
        assertEquals("John Doe", emp.getName());
        assertEquals("HR", emp.getDepartment());
        assertEquals("john@example.com", emp.getEmail());
        assertEquals("john", emp.getPassword());
    }
}

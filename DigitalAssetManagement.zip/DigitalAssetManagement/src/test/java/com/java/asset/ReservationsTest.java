package com.java.asset;

import static org.junit.Assert.*;
import org.junit.Test;

import com.java.asset.model.Reservations;

import java.text.ParseException;
import java.text.SimpleDateFormat;



public class ReservationsTest {

    @Test
    public void testToString() throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Reservations reservation = new Reservations(1, 1, 1, (sdf.parse("2024-01-05")), (sdf.parse("2024-01-10")), (sdf.parse("2024-01-15")), "Confirmed");
        String expected = "Reservations [reservation_id=1, asset_id=1, employee_id=1, reservation_date="+sdf.parse("2024-01-05")+ ", start_date="+sdf.parse("2024-01-10")+", end_date="+sdf.parse("2024-01-15") +", status=Confirmed]";
        assertEquals(expected, reservation.toString());
    }

    @Test
    public void testEquals() throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Reservations reservation1 = new Reservations(1, 1, 1, (sdf.parse("2024-01-05")), (sdf.parse("2024-01-10")), (sdf.parse("2024-01-15")), "Confirmed");
        Reservations reservation2 = new Reservations(1, 1, 1, (sdf.parse("2024-01-05")), (sdf.parse("2024-01-10")), (sdf.parse("2024-01-15")), "Confirmed");
        Reservations reservation3 = new Reservations(2, 2, 2, (sdf.parse("2024-01-10")), (sdf.parse("2024-01-15")), (sdf.parse("2024-01-20")), "Confirmed");
        assertTrue(reservation1.equals(reservation2));
        assertFalse(reservation1.equals(reservation3));
    }

    @Test
    public void testHashCode() throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Reservations reservation1 = new Reservations(1, 1, 1, (sdf.parse("2024-01-05")), (sdf.parse("2024-01-10")), (sdf.parse("2024-01-15")), "Confirmed");
        Reservations reservation2 = new Reservations(1, 1, 1, (sdf.parse("2024-01-05")), (sdf.parse("2024-01-10")), (sdf.parse("2024-01-15")), "Confirmed");
        assertEquals(reservation1.hashCode(), reservation2.hashCode());
    }

    @Test
    public void testGettersAndSetters() throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        
        Reservations reservation = new Reservations();
        reservation.setReservation_id(1);
        reservation.setAsset_id(1);
        reservation.setEmployee_id(1);
        reservation.setReservation_date((sdf.parse("2024-01-05")));
        reservation.setStart_date((sdf.parse("2024-01-10")));
        reservation.setEnd_date((sdf.parse("2024-01-15")));
        reservation.setStatus("Confirmed");

        assertEquals(1, reservation.getReservation_id());
        assertEquals(1, reservation.getAsset_id());
        assertEquals(1, reservation.getEmployee_id());
        assertEquals((sdf.parse("2024-01-05")), reservation.getReservation_date());
        assertEquals((sdf.parse("2024-01-10")), reservation.getStart_date());
        assertEquals((sdf.parse("2024-01-15")), reservation.getEnd_date());
        assertEquals("Confirmed", reservation.getStatus());
    }

    @Test
    public void testConstructors() throws ParseException {
        Reservations reservation = new Reservations();
        assertNotNull(reservation);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Reservations constructedReservation = new Reservations(1, 1, 1, (sdf.parse("2024-01-05")), (sdf.parse("2024-01-10")), (sdf.parse("2024-01-15")), "Confirmed");
        assertEquals(1, constructedReservation.getReservation_id());
        assertEquals(1, constructedReservation.getAsset_id());
        assertEquals(1, constructedReservation.getEmployee_id());
        assertEquals((sdf.parse("2024-01-05")), constructedReservation.getReservation_date());
        assertEquals((sdf.parse("2024-01-10")), constructedReservation.getStart_date());
        assertEquals((sdf.parse("2024-01-15")), constructedReservation.getEnd_date());
        assertEquals("Confirmed", constructedReservation.getStatus());
    }
}

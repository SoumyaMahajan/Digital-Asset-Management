package com.java.asset;

import static org.junit.Assert.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.junit.Test;

import com.java.asset.model.MaintenanceRecords;

public class MaintenanceRecordsTest {

    @Test
    public void testToString() throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        MaintenanceRecords record = new MaintenanceRecords(1, 1, (sdf.parse("2024-02-05")), "Replaced battery", 50.00);
        String expected = "MaintenanceRecords [maintenance_id=1, asset_id=1, maintenance_date="+sdf.parse("2024-02-05")+", description=Replaced battery, cost=50.0]";
        assertEquals(expected, record.toString());
    }

    @Test
    public void testEquals() throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        MaintenanceRecords record1 = new MaintenanceRecords(1, 1, (sdf.parse("2024-02-05")), "Replaced battery", 50.00);
        MaintenanceRecords record2 = new MaintenanceRecords(1, 1, (sdf.parse("2024-02-05")), "Replaced battery", 50.00);
        MaintenanceRecords record3 = new MaintenanceRecords(2, 2, (sdf.parse("2024-01-20")), "Cleaned printhead", 30.00);
        assertTrue(record1.equals(record2));
        assertFalse(record1.equals(record3));
    }

    @Test
    public void testHashCode() throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        MaintenanceRecords record1 = new MaintenanceRecords(1, 1, (sdf.parse("2024-02-05")), "Replaced battery", 50.00);
        MaintenanceRecords record2 = new MaintenanceRecords(1, 1, (sdf.parse("2024-02-05")), "Replaced battery", 50.00);
        assertEquals(record1.hashCode(), record2.hashCode());
    }

    @Test
    public void testGettersAndSetters() throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        
        MaintenanceRecords record = new MaintenanceRecords();
        record.setMaintenance_id(1);
        record.setAsset_id(1);
        record.setMaintenance_date((sdf.parse("2024-02-05")));
        record.setDescription("Replaced battery");
        record.setCost(50.00);

        assertEquals(1, record.getMaintenance_id());
        assertEquals(1, record.getAsset_id());
        assertEquals((sdf.parse("2024-02-05")), record.getMaintenance_date());
        assertEquals("Replaced battery", record.getDescription());
        assertEquals(50.00, record.getCost(), 0.001);
    }

    @Test
    public void testConstructors() throws ParseException {
        MaintenanceRecords record = new MaintenanceRecords();
        assertNotNull(record);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
   
        MaintenanceRecords constructedRecord = new MaintenanceRecords(1, 1, (sdf.parse("2024-02-05")), "Replaced battery", 50.00);

        assertEquals(1, constructedRecord.getMaintenance_id());
        assertEquals(1, constructedRecord.getAsset_id());
        assertEquals((sdf.parse("2024-02-05")), constructedRecord.getMaintenance_date());
        assertEquals("Replaced battery", constructedRecord.getDescription());
        assertEquals(50.00, constructedRecord.getCost(), 0.001);
    }
}
